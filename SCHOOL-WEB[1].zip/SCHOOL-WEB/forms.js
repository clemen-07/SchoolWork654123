const = form = document.querySelector("form"),
        nextBtn   =   form.querySelector(".nextBtn"),       
        backBtn   =   form.querySelector(".backBtn"),
        allinput   =   form.querySelectorAll(".first input");

nextBtn.addEventlistener("click", ()=> {
    allinput.forEach(input => {
        if(input.value != ""){
            form.classList.add('secActive');
        }else{
            form.classList.remove(secActive);
            alert("input is empty")
        }

    })
})